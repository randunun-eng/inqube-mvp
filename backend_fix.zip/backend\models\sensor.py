from sqlalchemy import Column, String, ForeignKey, Float, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid
from models.base import Base

class Sensor(Base):
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    machine_id = Column(UUID(as_uuid=True), ForeignKey("machine.id"))
    type = Column(String) # temp, energy, vibration
    unit = Column(String)
    mqtt_topic = Column(String, unique=True)
    
    machine = relationship("Machine", back_populates="sensors")
